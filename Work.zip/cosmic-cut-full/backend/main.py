from __future__ import annotations
import json, os, re, shutil, sqlite3, subprocess, threading, time, uuid, hmac, hashlib, base64, secrets
from pathlib import Path
from typing import Optional
from urllib.parse import urlparse
from collections import defaultdict, deque

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, BackgroundTasks, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT = Path(os.getenv('DATA_DIR', '/data')).resolve()
INBOX, OUT, TMP = ROOT/'inbox', ROOT/'output', ROOT/'tmp'
for p in (INBOX, OUT, TMP): p.mkdir(parents=True, exist_ok=True)
DB = ROOT/'jobs.sqlite3'
SECRET_KEY = os.getenv('COSMIC_SECRET_KEY', '')
if len(SECRET_KEY) < 32:
    # Development fallback only. Production must provide a persistent random secret.
    SECRET_KEY = secrets.token_hex(32)
MAX_BYTES = int(os.getenv('MAX_UPLOAD_MB', '1024')) * 1024 * 1024
MAX_SECONDS = int(os.getenv('MAX_VIDEO_SECONDS', '7200'))
OUTPUT_TTL_SECONDS = int(os.getenv('OUTPUT_TTL_HOURS', '24')) * 3600
JOB_TTL_SECONDS = int(os.getenv('JOB_TTL_DAYS', '7')) * 86400
_rate_lock = threading.Lock()
_rate_events = defaultdict(deque)
MODEL_NAME = os.getenv('WHISPER_MODEL', 'small')
_model = None
_model_lock = threading.Lock()

app = FastAPI(title='COSMIC CUT API', version='1.0.0')
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('CORS_ORIGINS','*').split(','), allow_credentials=False, allow_methods=['GET','POST'], allow_headers=['*'])

@app.middleware('http')
async def security_headers(request, call_next):
    # Limit expensive job submissions per client IP (in-memory; use a shared
    # limiter such as Redis when deploying multiple workers/replicas).
    if request.url.path in ('/api/jobs/upload', '/api/jobs/youtube') and request.method == 'POST':
        client = request.client.host if request.client else 'unknown'
        now = time.time()
        with _rate_lock:
            events = _rate_events[client]
            while events and now - events[0] > 3600:
                events.popleft()
            if len(events) >= int(os.getenv('MAX_JOBS_PER_HOUR', '5')):
                from fastapi.responses import JSONResponse
                return JSONResponse({'detail': 'Слишком много задач. Попробуйте позже.'}, status_code=429)
            events.append(now)
    response = await call_next(request)
    response.headers.setdefault('X-Content-Type-Options', 'nosniff')
    response.headers.setdefault('Referrer-Policy', 'strict-origin-when-cross-origin')
    response.headers.setdefault('X-Frame-Options', 'DENY')
    return response


class AuthRequest(BaseModel):
    email: str
    password: str

def password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 310000)
    return base64.urlsafe_b64encode(salt).decode()+'.'+base64.urlsafe_b64encode(digest).decode()

def verify_password(password: str, stored: str) -> bool:
    try:
        salt_s, digest_s = stored.split('.',1)
        salt=base64.urlsafe_b64decode(salt_s); expected=base64.urlsafe_b64decode(digest_s)
        actual=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,310000)
        return hmac.compare_digest(actual,expected)
    except Exception: return False

def make_token(user_id: str) -> str:
    expiry=str(int(time.time())+60*60*24*7)
    payload=f'{user_id}.{expiry}'
    sig=hmac.new(SECRET_KEY.encode(),payload.encode(),hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f'{payload}.{sig}'.encode()).decode().rstrip('=')

def current_user(authorization: str | None = Header(default=None)) -> str:
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Войдите в аккаунт')
    try:
        raw=base64.urlsafe_b64decode(authorization[7:]+'===').decode()
        uid,expiry,sig=raw.split('.',2); payload=f'{uid}.{expiry}'
        expected=hmac.new(SECRET_KEY.encode(),payload.encode(),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig,expected) or int(expiry)<int(time.time()): raise ValueError()
        c=db(); user=c.execute('SELECT id FROM users WHERE id=?',(uid,)).fetchone(); c.close()
        if not user: raise ValueError()
        return uid
    except Exception: raise HTTPException(401,'Сессия недействительна. Войдите снова')

@app.post('/api/auth/register')
def register(req: AuthRequest):
    email=req.email.strip().lower()
    if not re.fullmatch(r'[^@\s]{1,64}@[^@\s]{1,255}\.[^@\s]{2,24}',email): raise HTTPException(400,'Проверьте адрес электронной почты')
    if len(req.password)<10 or len(req.password)>128: raise HTTPException(400,'Пароль должен содержать от 10 до 128 символов')
    uid=uuid.uuid4().hex; c=db()
    try:
        c.execute('INSERT INTO users(id,email,password_hash,created) VALUES(?,?,?,?)',(uid,email,password_hash(req.password),time.time())); c.commit()
    except sqlite3.IntegrityError: raise HTTPException(409,'Аккаунт с такой почтой уже существует')
    finally: c.close()
    return {'token':make_token(uid),'user':{'id':uid,'email':email},'plan':'free'}

@app.post('/api/auth/login')
def login(req: AuthRequest):
    c=db(); row=c.execute('SELECT id,email,password_hash FROM users WHERE email=?',(req.email.strip().lower(),)).fetchone(); c.close()
    if not row or not verify_password(req.password,row['password_hash']): raise HTTPException(401,'Неверная почта или пароль')
    return {'token':make_token(row['id']),'user':{'id':row['id'],'email':row['email']},'plan':'free'}

@app.get('/api/auth/me')
def me(uid: str=Depends(current_user)):
    c=db(); row=c.execute('SELECT id,email,created FROM users WHERE id=?',(uid,)).fetchone(); c.close()
    return {'user':dict(row),'plan':'free','subscription':'not_configured'}

class UrlRequest(BaseModel):
    url: str
    duration: str = '60-70'
    ratio: str = '9:16'
    count: int = 5
    language: str = 'auto'
    word_subtitles: bool = True
    remove_pauses: bool = False
    highlights: bool = True
    rights_confirmed: bool = False


def db():
    c=sqlite3.connect(DB, timeout=30); c.row_factory=sqlite3.Row
    c.execute('''CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,status TEXT,progress INTEGER,message TEXT,created REAL,source TEXT,settings TEXT,result TEXT,error TEXT)''')
    c.execute('''CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,created REAL NOT NULL)''')
    cols={row['name'] for row in c.execute('PRAGMA table_info(jobs)').fetchall()}
    if 'user_id' not in cols: c.execute('ALTER TABLE jobs ADD COLUMN user_id TEXT')
    c.commit(); return c

def update(jid, **kw):
    c=db(); cols=','.join(f'{k}=?' for k in kw); c.execute(f'UPDATE jobs SET {cols} WHERE id=?', [*kw.values(),jid]); c.commit(); c.close()

def create_job(source, settings):
    jid=uuid.uuid4().hex
    c=db(); c.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?)',(jid,'queued',0,'В очереди',time.time(),source,json.dumps(settings,ensure_ascii=False),None,None)); c.commit(); c.close(); return jid

def run(cmd, timeout=3600):
    # No shell=True: all arguments remain separate and user input is never a shell command.
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
    if p.returncode: raise RuntimeError((p.stderr or p.stdout)[-2500:])
    return p.stdout

def duration_of(path):
    raw=run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(path)])
    return float(raw.strip())

def get_model():
    global _model
    with _model_lock:
        if _model is None:
            from faster_whisper import WhisperModel
            _model=WhisperModel(MODEL_NAME, device=os.getenv('WHISPER_DEVICE','cpu'), compute_type=os.getenv('WHISPER_COMPUTE','int8'))
    return _model

def transcribe(path, language):
    model=get_model()
    lang=None if language in ('auto','Автоопределение','') else {'Русский':'ru','English':'en','Українська':'uk'}.get(language,language)
    segments, info=model.transcribe(str(path), language=lang, word_timestamps=True, vad_filter=True)
    out=[]
    for s in segments:
        words=[]
        for w in (s.words or []):
            words.append({'start':float(w.start),'end':float(w.end),'text':w.word.strip()})
        out.append({'start':float(s.start),'end':float(s.end),'text':s.text.strip(),'words':words})
    return out, info.language

def score_segment(text):
    t=text.lower(); score=min(len(t)/180,1.5)
    patterns=[r'но\b',r'однако',r'оказалось',r'в итоге',r'представьте',r'почему',r'секрет',r'ошибка',r'никогда',r'впервые',r'самый',r'лучший',r'деньги',r'тысяч',r'миллион',r'\?',r'!']
    score += sum(0.45 for p in patterns if re.search(p,t))
    if len(t)<50: score-=1
    return score

def select_clips(segments, duration, count, highlights):
    windows={'30-45':(30,45),'45-60':(45,60),'60-70':(60,70),'70-90':(70,90)}
    lo,hi=windows.get(duration,(60,70)); target=(lo+hi)/2
    total=segments[-1]['end'] if segments else 0
    if total<lo: raise RuntimeError(f'Видео слишком короткое: {total:.0f} сек. Нужно минимум {lo} сек.')
    candidates=[]
    step=max(8,int(target/5))
    start=0
    while start+lo<=total:
        end=min(start+target,total)
        text=' '.join(s['text'] for s in segments if s['end']>=start and s['start']<=end)
        if text.strip():
            score=score_segment(text) if highlights else 1
            candidates.append({'start':start,'end':end,'score':score,'text':text})
        start+=step
    candidates.sort(key=lambda x:x['score'],reverse=True)
    chosen=[]
    for c in candidates:
        if all(c['end']<=x['start'] or c['start']>=x['end'] for x in chosen): chosen.append(c)
        if len(chosen)>=count: break
    if not chosen: chosen=[{'start':0,'end':min(target,total),'score':0,'text':''}]
    return sorted(chosen,key=lambda x:x['start'])

def ass_time(seconds):
    cs=max(0,int(seconds*100)); h=cs//360000; m=(cs%360000)//6000; s=(cs%6000)//100
    return f'{h}:{m:02d}:{s:02d}.{cs%100:02d}'

def make_ass(words, start, end, outpath):
    header='''[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\nScaledBorderAndShadow: yes\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Arial,76,&H00FFFFFF,&H0000FFFF,&H00101018,&H99000000,-1,0,1,5,2,2,80,80,300,1\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n'''
    relevant=[w for w in words if w['end']>=start and w['start']<=end and w['text']]
    # Whisper text is untrusted input: escape ASS override syntax.
    relevant=[{**w, 'text': w['text'].replace('\\', '\\\\').replace('{', '\\{').replace('}', '\\}').replace('\n', ' ')} for w in relevant]
    lines=[]
    # Show short phrase with current word highlighted; timings follow word alignment.
    for i,w in enumerate(relevant):
        group=relevant[max(0,i-3):min(len(relevant),i+4)]
        phrase=' '.join((r'{\c&H00FFFFFF&}'+x['text']+r'{\c&H00FFFFFF&}') if j!=(i-max(0,i-3)) else (r'{\c&H00D8F955&\bord6}'+x['text']+r'{\c&H00FFFFFF&\bord5}') for j,x in enumerate(group))
        a=max(start,w['start']); b=min(end,max(w['end'],w['start']+0.12))
        lines.append(f'Dialogue: 0,{ass_time(a-start)},{ass_time(b-start)},Default,,0,0,0,,{phrase}')
    outpath.write_text(header+'\n'.join(lines)+'\n',encoding='utf-8')

def process(jid, source, settings):
    work=TMP/jid; work.mkdir(parents=True,exist_ok=True)
    input_path=Path(source)
    try:
        update(jid,status='processing',progress=5,message='Подготовка видео')
        if not input_path.is_file() or input_path.stat().st_size == 0:
            raise RuntimeError('Загруженный файл пуст или не найден')
        dur=duration_of(input_path)
        if dur <= 0:
            raise RuntimeError('Не удалось определить длительность видеофайла')
        if dur>MAX_SECONDS: raise RuntimeError(f'Длительность превышает лимит {MAX_SECONDS//60} минут.')
        update(jid,progress=15,message='Распознавание речи (Whisper)')
        segs, detected=transcribe(input_path,settings.get('language','auto'))
        words=[w for s in segs for w in s['words']]
        update(jid,progress=45,message='Поиск интересных фрагментов')
        clips=select_clips(segs,settings.get('duration','60-70'),int(settings.get('count',5)),bool(settings.get('highlights',True)))
        ratio=settings.get('ratio','9:16')
        if ratio=='9:16': vf="scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
        elif ratio=='1:1': vf="scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080"
        else: vf="scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080"
        results=[]
        for i,c in enumerate(clips,1):
            update(jid,progress=45+int(45*i/len(clips)),message=f'Рендер клипа {i} из {len(clips)}')
            clipfile=OUT/f'{jid}_{i:02d}.mp4'
            cmd=['ffmpeg','-y','-ss',str(c['start']),'-i',str(input_path),'-t',str(c['end']-c['start']),'-vf',vf,'-c:v','libx264','-preset','veryfast','-crf','21','-c:a','aac','-b:a','160k','-movflags','+faststart']
            if settings.get('word_subtitles',True):
                ass=work/f'clip_{i:02d}.ass'; make_ass(words,c['start'],c['end'],ass)
                # Escape path for FFmpeg subtitles filter.
                ass_arg=str(ass).replace('\\','/').replace(':','\\:').replace("'","\\'")
                cmd[cmd.index('-vf')+1]=vf+f",subtitles='{ass_arg}'"
            cmd += [str(clipfile)]; run(cmd)
            results.append({'name':clipfile.name,'url':f'/api/files/{clipfile.name}','start':round(c['start'],2),'end':round(c['end'],2),'score':round(c['score'],2)})
        result={'clips':results,'language':detected,'transcript':segs}
        update(jid,status='done',progress=100,message='Готово',result=json.dumps(result,ensure_ascii=False))
    except Exception as e:
        # Keep diagnostics in server logs; expose a concise, non-sensitive message.
        print(f'COSMIC CUT job {jid} failed: {type(e).__name__}: {e}', flush=True)
        public_error = str(e) if isinstance(e, RuntimeError) else 'Внутренняя ошибка обработки. Попробуйте другой файл или повторите позже.'
        update(jid,status='error',progress=100,message='Ошибка обработки',error=public_error[:500])
    finally:
        # Source uploads and temporary files are removed after processing.
        try:
            if input_path.exists() and input_path.parent in (INBOX,work): input_path.unlink()
            shutil.rmtree(work,ignore_errors=True)
        except Exception: pass


def validate_settings(duration,ratio,count):
    if duration not in ('30-45','45-60','60-70','70-90'): raise HTTPException(400,'Неверная длительность клипа')
    if ratio not in ('9:16','1:1','16:9'): raise HTTPException(400,'Неверный формат кадра')
    if not 1<=count<=10: raise HTTPException(400,'Количество клипов должно быть от 1 до 10')

def cleanup_expired():
    """Remove old exports and job metadata to prevent unbounded disk growth."""
    now = time.time()
    for item in OUT.iterdir():
        try:
            if item.is_file() and now - item.stat().st_mtime > OUTPUT_TTL_SECONDS:
                item.unlink(missing_ok=True)
        except OSError:
            pass
    c = db()
    try:
        cutoff = now - JOB_TTL_SECONDS
        c.execute('DELETE FROM jobs WHERE created < ?', (cutoff,))
        c.commit()
    finally:
        c.close()

def cleanup_loop():
    while True:
        try:
            cleanup_expired()
        except Exception as exc:
            print(f'COSMIC CUT cleanup failed: {exc}', flush=True)
        time.sleep(3600)

@app.on_event('startup')
def start_cleanup():
    threading.Thread(target=cleanup_loop, daemon=True, name='cosmic-cleanup').start()

@app.get('/api/health')
def health(): return {'status':'ok','service':'COSMIC CUT','processing':'Whisper + FFmpeg'}

@app.post('/api/jobs/upload')
async def upload_job(background: BackgroundTasks, uid: str=Depends(current_user), file: UploadFile=File(...), duration: str=Form('60-70'), ratio: str=Form('9:16'), count: int=Form(5), language: str=Form('auto'), word_subtitles: bool=Form(True), highlights: bool=Form(True), rights_confirmed: bool=Form(False)):
    validate_settings(duration,ratio,count)
    if not rights_confirmed: raise HTTPException(400,'Подтвердите, что у вас есть права на обработку видео.')
    ext=Path(file.filename or '').suffix.lower()
    if ext not in ('.mp4','.mov','.webm','.mkv'): raise HTTPException(400,'Поддерживаются MP4, MOV, WEBM и MKV')
    jid=uuid.uuid4().hex; dest=INBOX/f'{jid}{ext}'; size=0
    with dest.open('wb') as out:
        while chunk:=await file.read(1024*1024):
            size+=len(chunk)
            if size>MAX_BYTES: dest.unlink(missing_ok=True); raise HTTPException(413,f'Файл больше лимита {MAX_BYTES//1024//1024} МБ')
            out.write(chunk)
    settings={'duration':duration,'ratio':ratio,'count':count,'language':language,'word_subtitles':word_subtitles,'highlights':highlights}
    c=db(); c.execute('INSERT INTO jobs(id,status,progress,message,created,source,settings,result,error,user_id) VALUES(?,?,?,?,?,?,?,?,?,?)',(jid,'queued',0,'В очереди',time.time(),str(dest),json.dumps(settings,ensure_ascii=False),None,None,uid)); c.commit(); c.close()
    background.add_task(process,jid,str(dest),settings)
    return {'id':jid,'status':'queued'}

def download_and_process_youtube(jid: str, url: str, settings: dict):
    """Download YouTube media outside the request/response cycle, then process it."""
    pattern = INBOX / f'{jid}.%(ext)s'
    downloaded = None
    try:
        update(jid, status='processing', progress=2, message='Проверка и загрузка видео с YouTube')
        info = json.loads(run(['yt-dlp','--no-playlist','--dump-single-json','--skip-download',url]))
        if not info.get('duration'):
            raise RuntimeError('Не удалось определить длительность видео')
        if info['duration'] > MAX_SECONDS:
            raise RuntimeError(f'Видео длиннее разрешённых {MAX_SECONDS//60} минут')
        run(['yt-dlp','--no-playlist','-f','bv*[height<=1080]+ba/b[height<=1080]','--merge-output-format','mp4','-o',str(pattern),url])
        preferred = INBOX / f'{jid}.mp4'
        if preferred.is_file():
            downloaded = preferred
        else:
            matches = [x for x in INBOX.glob(f'{jid}.*') if x.is_file()]
            if not matches:
                raise RuntimeError('Загрузчик не создал видеофайл')
            downloaded = matches[0]
        process(jid, str(downloaded), settings)
    except Exception as exc:
        update(jid, status='error', progress=100, message='Не удалось загрузить видео с YouTube', error=str(exc)[-1200:])
        for candidate in INBOX.glob(f'{jid}.*'):
            candidate.unlink(missing_ok=True)

@app.post('/api/jobs/youtube')
def youtube_job(req: UrlRequest, background: BackgroundTasks, uid: str=Depends(current_user)):
    validate_settings(req.duration,req.ratio,req.count)
    if not req.rights_confirmed:
        raise HTTPException(400,'Подтвердите, что у вас есть права или разрешение на обработку этого видео.')
    u=urlparse(req.url)
    if u.scheme not in ('https','http') or u.hostname not in ('youtube.com','www.youtube.com','m.youtube.com','youtu.be','www.youtu.be') or u.username or u.password or u.port not in (None,80,443):
        raise HTTPException(400,'Разрешены только ссылки youtube.com и youtu.be')
    jid=uuid.uuid4().hex
    settings=req.model_dump(exclude={'url','rights_confirmed'})
    c=db()
    c.execute('INSERT INTO jobs(id,status,progress,message,created,source,settings,result,error,user_id) VALUES(?,?,?,?,?,?,?,?,?,?)',(jid,'queued',0,'Ожидание загрузки с YouTube',time.time(), 'youtube', json.dumps(settings,ensure_ascii=False), None, None,uid))
    c.commit(); c.close()
    background.add_task(download_and_process_youtube,jid,req.url,settings)
    return {'id':jid,'status':'queued'}

@app.get('/api/jobs/{jid}')
def job_status(jid:str, uid: str=Depends(current_user)):
    c=db(); row=c.execute('SELECT * FROM jobs WHERE id=? AND user_id=?',(jid,uid)).fetchone(); c.close()
    if not row: raise HTTPException(404,'Задача не найдена')
    data={'id':row['id'],'status':row['status'],'progress':row['progress'],'message':row['message'],'created':row['created']}
    if row['result']: data['result']=json.loads(row['result'])
    if row['error']: data['error']=row['error']
    return data

# No public global job listing: it would expose every visitor's job IDs and transcripts.

@app.get('/api/files/{filename}')
def get_file(filename:str, uid: str=Depends(current_user)):
    if Path(filename).name!=filename: raise HTTPException(400,'Недопустимое имя файла')
    match=re.match(r'^([a-f0-9]{32})_',filename)
    if not match: raise HTTPException(404,'Файл не найден')
    c=db(); owned=c.execute('SELECT 1 FROM jobs WHERE id=? AND user_id=?',(match.group(1),uid)).fetchone(); c.close()
    if not owned: raise HTTPException(404,'Файл не найден')
    path=OUT/filename
    if not path.is_file(): raise HTTPException(404,'Файл не найден или уже удалён')
    return FileResponse(path,media_type='video/mp4',filename=filename)

# Serve the responsive web app from the same origin as the API.
app.mount('/', StaticFiles(directory=str(Path(__file__).resolve().parents[1] / 'frontend'), html=True), name='frontend')
